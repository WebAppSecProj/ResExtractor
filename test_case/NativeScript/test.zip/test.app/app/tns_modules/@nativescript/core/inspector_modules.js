require("./../../../runtime.js");require("./../../../vendor.js");module.exports =
(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["tns_modules/@nativescript/core/inspector_modules"],{

/***/ "~/package.json":
/***/ (function(module, exports) {

module.exports = require("~/package.json");

/***/ })

},[["../node_modules/@nativescript/core/inspector_modules.js","runtime","vendor"]]]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJ+L3BhY2thZ2UuanNvblwiIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLDJDIiwiZmlsZSI6InRuc19tb2R1bGVzL0BuYXRpdmVzY3JpcHQvY29yZS9pbnNwZWN0b3JfbW9kdWxlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIn4vcGFja2FnZS5qc29uXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=